import java.util.Hashtable;

public class XFastTrie {
    //the maximum number of bit the trie can store (for example, 3 in binary is 011, it is 3 bits).
    //the number of levels the trie has = Max_Bit-1.
    //the size of hash table of each level = 2^Max_Bit.
    public final int Max_Bit;
    public Hashtable[] levels;
    //usually the value of a node is 0 or 1; -1 stands for the root.
    public TrieNode root = new TrieNode("-1", null, null, null, 0);
    //this node is the header of the doubly-linked list of the leaves
    public TrieNode leaves;

    //an empty X-Fast Trie has a root, and an array to store the hash table of each level.
    public XFastTrie(int max_bit) {
        Max_Bit = max_bit;
        levels = new Hashtable[Max_Bit+1];
        for (int i = 0; i < Max_Bit+1; i++) {
            levels[i] = new Hashtable<String, TrieNode>();
        }
        levels[0].put("-1", root);
    }

    public void insert(int value){
        //convert value to binary
        String binaryString = Integer.toBinaryString(value);
        //make sure that all binary strings have length of Max_Bit.
        binaryString = String.format("%"+Max_Bit+"s", binaryString).replace(' ', '0');

        //try to find the path representing the value(binary)
        //iterate at each level, search in the hash table
        TrieNode parent = root;
        for(int i=1; i<Max_Bit+1; i++){
            //if the current level is empty
            if(levels[i].isEmpty()){
                //create a new node
                TrieNode newNode = new TrieNode(binaryString.substring(0,i), parent, null, null, i);
                //add it into the trie as a child of its parent; "0": left child, "1": right child
                Helpers.addAsChild(newNode, parent, binaryString.substring(i-1,i).equals("0"));
                levels[i].put(binaryString.substring(0,i), newNode);
                //update the parent
                parent = newNode;
                //if the node is a leaf
                if(i==Max_Bit){//add the node into the doubly-linked list
                    leaves = newNode;
                }
            }
            //if the current level is not empty
            else{
                //check if there is an existing path we can follow
                TrieNode possiblePath = (TrieNode) levels[i].get(binaryString.substring(0,i));
                if(possiblePath == null){//there is no path, then create a new node and add as above
                    TrieNode newNode = new TrieNode(binaryString.substring(0,i), parent, null, null, i);
                    Helpers.addAsChild(newNode, parent, binaryString.substring(i-1,i).equals("0"));
                    levels[i].put(binaryString.substring(0,i), newNode);
                    parent = newNode;
                    //if the node is a leaf, and we cannot find it in the doubly-linked list
                    if(i==Max_Bit){
                        if(leaves.prev == null){
                            leaves.prev = newNode;
                            leaves.next = newNode;
                            newNode.prev = leaves;
                            newNode.next = leaves;
                            if(Integer.parseInt(newNode.value) < Integer.parseInt(leaves.value)){
                                leaves = newNode;
                            }
                        }else{
                            //add leaf to its position in the doubly-linked list by order
                            TrieNode temp = leaves;
                            if(Integer.parseInt(newNode.value) > Integer.parseInt(temp.value)
                                    && Integer.parseInt(newNode.value) < Integer.parseInt(temp.next.value)){
                                newNode.prev = temp;
                                newNode.next = temp.next;
                                temp.next.prev = newNode;
                                temp.next = newNode;
                                break;
                            }else{
                                temp = temp.next;
                            }
                            boolean flag = false;
                            while(!temp.equals(leaves)){
                                if(Integer.parseInt(newNode.value) > Integer.parseInt(temp.value)
                                        && Integer.parseInt(newNode.value) < Integer.parseInt(temp.next.value)){
                                    newNode.prev = temp;
                                    newNode.next = temp.next;
                                    temp.next.prev = newNode;
                                    temp.next = newNode;
                                    flag = true;
                                    break;
                                }
                                temp = temp.next;
                            }
                            if(!flag){
                                newNode.prev = leaves.prev;
                                newNode.next = leaves;
                                leaves.prev.next = newNode;
                                leaves.prev = newNode;
                            }
                        }
                        //after adding the leaf, update all the pointers that originally point to leaves on its right
                        //update from newNode.next to leaves;
                        TrieNode temp = newNode.next;
                        while(!temp.equals(leaves)){
                            for(TrieNode n : temp.pointedBy){
                                if(n.rightChild == null){
                                    if(Integer.parseInt(n.value) <= Integer.parseInt(newNode.value.substring(0,i))){
                                        n.pointer = newNode;
                                        newNode.pointedBy.add(n);
                                        temp.pointedBy.remove(n);
                                        break;
                                    }
                                }
                                else{
                                    if(Integer.parseInt(n.value) <= Integer.parseInt(newNode.value.substring(0,i))-1){
                                        n.pointer = newNode;
                                        newNode.pointedBy.add(n);
                                        temp.pointedBy.remove(n);
                                        break;
                                    }
                                }
                            }
                            temp = temp.next;
                        }
                    }
                }else{//there is a path we can follow, in this case we just update the parent and move to the next level
                    parent = possiblePath;
                }
            }
        }
        //after inserting, add pointers to all nodes that has no pointer
        for(int i=1; i<Max_Bit+1; i++){
            for(Object key : levels[i].keySet()) {
                TrieNode node = (TrieNode) levels[i].get(key);
                if((node.leftChild == null || node.rightChild == null) && node.pointer == null){
                    //add pointer
                    TrieNode leaf = leaves;
                    //the pointer is to replace its left child
                    if(node.leftChild == null){
                        if(Integer.parseInt(node.value) > Integer.parseInt(leaf.value.substring(0,i))){
                            leaf = leaf.next;
                        }else if(Integer.parseInt(node.value) <= Integer.parseInt(leaf.value.substring(0,i))){
                            node.pointer = leaf;
                            leaf.pointedBy.add(node);
                        }else{
                            leaf = leaf.next;
                        }
                        while(!leaf.equals(leaves)){
                            if(Integer.parseInt(node.value) > Integer.parseInt(leaf.value.substring(0,i))){
                                leaf = leaf.next;
                            }else if(Integer.parseInt(node.value) <= Integer.parseInt(leaf.value.substring(0,i))){
                                node.pointer = leaf;
                                leaf.pointedBy.add(node);
                                break;
                            }else{
                                leaf = leaf.next;
                            }
                        }
                    }
                    //the pointer is to replace its right child
                    else{
                        if(Integer.parseInt(node.value) > Integer.parseInt(leaf.value.substring(0,i))){
                            leaf = leaf.next;
                        }else if(Integer.parseInt(node.value) <= Integer.parseInt(leaf.value.substring(0,i))-1){
                            node.pointer = leaf;
                            leaf.pointedBy.add(node);
                        }else{
                            leaf = leaf.next;
                        }
                        while(leaf != null && !leaf.equals(leaves)){
                            if(Integer.parseInt(node.value) > Integer.parseInt(leaf.value.substring(0,i))){
                                if(leaf.next != null) {
                                    leaf = leaf.next;
                                }else{
                                    break;
                                }
                            }else if(Integer.parseInt(node.value) <= Integer.parseInt(leaf.value.substring(0,i))-1){
                                node.pointer = leaf;
                                leaf.pointedBy.add(node);
                                break;
                            }else{
                                if(leaf.next != null) {
                                    leaf = leaf.next;
                                }else{
                                    break;
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    public void search(int value){
        Helpers.printTrie(levels);
        Helpers.printLeaves(leaves);
        //convert value to binary
        String binaryString = Integer.toBinaryString(value);
        //make sure that all binary strings have length of Max_Bit.
        binaryString = String.format("%"+Max_Bit+"s", binaryString).replace(' ', '0');
        System.out.println("Search for: "+value+" ("+binaryString+")");

        //we first try to find the value in level=height/2, so that we can determine which part we are going to look at
        boolean stillInTrie = levels[(Max_Bit+1)/2].get(binaryString.substring(0,(Max_Bit+1)/2))!=null;
        //System.out.println(stillInTrie);
        //if it falls out of the trie before height/2, we only need to check the first 1/2 levels
        if(!stillInTrie) {
            TrieNode current = root;
            for (int i = 1; i <= (Max_Bit + 1)/2; i++) {
                current = (TrieNode) levels[i].get(binaryString.substring(0, i));
                if (current == null) {
                    //go to the previous level, find its common path, and try to follow the possible pointer to find its succesor
                    if (i == 1) {//the previous level is the root, then there is no possible pointer
                        System.out.println("No Value, No Successor");
                        return;
                    } else {//try to follow the pointer
                        TrieNode temp = (TrieNode) levels[i - 1].get(binaryString.substring(0, i - 1));
                        if (temp.pointer == null) {
                            System.out.println("No Value, No Successor");
                            return;
                        } else {
                            System.out.print("Pointer Exists: ");
                            System.out.print(temp.value);
                            System.out.print("->");
                            System.out.println(temp.pointer.value);
                            System.out.print("Successor: ");
                            System.out.println(temp.pointer.value);
                        }
                    }
                }
            }
            if(current != null){
                System.out.println("Has Value: "+current.value);
            }
        }
        //if it still in the trie after level height/2, we only need to check the last 1/2 levels
        else{
            TrieNode current = (TrieNode) levels[(Max_Bit+1)/2].get(binaryString.substring(0,(Max_Bit+1)/2));
            for (int i = (Max_Bit + 1)/2; i < Max_Bit+1; i++) {
                current = (TrieNode) levels[i].get(binaryString.substring(0, i));
                if (current == null) {
                    //go to the previous level, find its common path, and try to follow the possible pointer to find its succesor
                    if (i == 1) {//the previous level is the root, then there is no possible pointer
                        System.out.println("No Value, No Successor");
                        break;
                    } else {//try to follow the pointer
                        TrieNode temp = (TrieNode) levels[i - 1].get(binaryString.substring(0, i - 1));
                        if (temp.pointer == null) {
                            System.out.println("No Value, No Successor");
                            break;
                        } else {
                            System.out.print("Pointer Exists: ");
                            System.out.print(temp.value);
                            System.out.print("->");
                            System.out.println(temp.pointer.value);
                            System.out.print("Successor: ");
                            System.out.println(temp.pointer.value);
                        }
                    }
                }
            }
            if(current != null){
                System.out.println("Has Value: "+current.value);
            }
        }
    }

    public void remove(int value){
        //convert value to binary
        String binaryString = Integer.toBinaryString(value);
        //make sure that all binary strings have length of Max_Bit.
        binaryString = String.format("%"+Max_Bit+"s", binaryString).replace(' ', '0');

        //find the leaf representing the value
        TrieNode temp = leaves;
        if(temp.next == null){
            System.out.println("No Such Value to Remove");
        }
        else{
            //find the leaf
            while(!temp.value.equals(binaryString)){
                if(temp.next == leaves){
                    System.out.println("No Such Value to Remove");
                }
                else{
                    temp = temp.next;
                }
            }

            //delete the leaf, and change all pointers pointing to it to its next node if its next node is not its previous.
            int numLevels = Max_Bit;
            temp.prev.next = temp.next;
            temp.next.prev = temp.prev;
            if(!temp.next.equals(temp.prev)){
                if(!temp.pointedBy.isEmpty()) {
                    for (TrieNode n : temp.pointedBy) {
                        n.pointer = temp.next;
                    }
                }
            }
            temp.prev = null;
            temp.next = null;
            levels[numLevels].remove(temp.value);
            numLevels --;
            while(temp != null && temp.parent != null){
                if(temp.parent.leftChild == temp){
                    temp.parent.leftChild = null;
                }else if(temp.rightChild == temp){
                    temp.parent.rightChild = null;
                }
                if(temp.parent.leftChild == null && temp.rightChild == null){
                    if(temp.pointer != null) {
                        temp.pointer.pointedBy.remove(temp);
                        temp.pointer = null;
                    }
                    temp = temp.parent;
                    levels[numLevels].remove(temp.value);
                    numLevels --;
                }else{
                    break;
                }
            }
        }
    }
}

