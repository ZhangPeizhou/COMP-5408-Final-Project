public class Tests {
    public static void main(String[] args) {
        XFastTrie XFastTrie1 = new XFastTrie(3);
        XFastTrie1.insert(3);//011 - [PASS]
        XFastTrie1.search(3);//011 - should return value 011 - [PASS]
        XFastTrie1.search(1);//001 - should return successor 011 - [PASS]

        XFastTrie1.insert(1);//001 - [PASS]
        XFastTrie1.insert(6);//110 - [PASS]
        XFastTrie1.search(4);//100 - should return successor 110 - [PASS]

        XFastTrie1.insert(5);//101 - [PASS]
        XFastTrie1.search(4);//100 - should return successor 101 - [PASS]

        XFastTrie1.search(7);//111 - should not return value or successor - [PASS]

        XFastTrie1.remove(5);//101 - [PASS]
        XFastTrie1.search(4);//100 - should return successor 110 - [PASS]
        XFastTrie1.remove(6);//110 - [PASS]
        XFastTrie1.search(4);//100 - should not return value or successor - [PASS]
    }
}
