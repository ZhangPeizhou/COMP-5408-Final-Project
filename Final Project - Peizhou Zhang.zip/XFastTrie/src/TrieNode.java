import java.util.ArrayList;

public class TrieNode {
    public String value;
    public TrieNode parent;
    public TrieNode leftChild;
    public TrieNode rightChild;
    public TrieNode pointer;
    public ArrayList<TrieNode> pointedBy = new ArrayList<>();
    public int depth;
    //the below two are only in use when a node is a leaf (in the doubly linked list)
    public TrieNode next;
    public TrieNode prev;

    public TrieNode(String val, TrieNode p, TrieNode leftC, TrieNode rightC, int d){
        this.value = val;
        this.parent = p;
        this.leftChild = leftC;
        this.rightChild = rightC;
        this.depth = d;
    }
}
