import java.util.Hashtable;

public class Helpers {
    public static void addAsChild(TrieNode node, TrieNode parent, boolean isLeftChild){
        node.parent = parent;
        if(isLeftChild){
            parent.leftChild = node;
        }else{
            parent.rightChild = node;
        }
    }

    public static void printTrie(Hashtable[] levels){
        System.out.println("------------------------------------");
        for(int i=0; i<levels.length; i++){
            for (Object key : levels[i].keySet()) {
                System.out.print(key);
                System.out.print(", ");
            }
            System.out.println(' ');
        }
        System.out.println("------------------------------------");
    }

    public static void printLeaves(TrieNode leaves){
        System.out.println("====================================");
        TrieNode temp = leaves;
        System.out.print(temp.value);
        System.out.print("<-->");
        if(temp.next != null){
            temp = temp.next;
            while(!temp.equals(leaves)){
                System.out.print(temp.value);
                System.out.print("<-->");
                temp = temp.next;
            }
        }
        System.out.println(' ');
        System.out.println("====================================");
    }
}
